<div id="footer">Copyright &copy; 2011 Pasha the Painter<br />
<a href="mailto:yourfirstname@yourlastname.com">yourfirstname@yourlastname.com</a></div>
</div>
</div>
</body>
</html>
