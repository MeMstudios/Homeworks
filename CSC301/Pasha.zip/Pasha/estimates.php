<?php 
	$page_title = 'Pasha the Painter Estimates';
	include('includes/header.inc.php');
?>
<div id="rightcolumn">
  <p>Request a Free Estimate.</p>
  <form method="post" action="painter.php">
    <div class="myRow">
      <label class="labelCol" for="myName">Name: </label>
      <input type="text" name="myName" id="myName" />
    </div>
    <div class="myRow">
      <label class="labelCol" for="myEmail">E-mail: </label>
      <input type="text" name="myEmail" id="myEmail" />
    </div>
	<div class="myRow">
      <label class="labelCol" for="myCity">City: </label>
      <input type="text" name="myCity" id="myCity" />
    </div>
	<div class="myRow">
      <label class="labelCol" for="myZip">Zip Code: </label>
      <input type="text" name="myZip" id="myZip" />
    </div>	
	<div class="myRow">
	<?php
	$states = array ('KY', 'OH', 'IN');
	echo '<label class="labelCol" for="myState">State: </label>
		  <select name="myState" id="myState">';
		  foreach ($states as $value) {
			  echo "<option value=\"$value\">
			  $value</option>";
		  }
		echo '</select>';
	
	?>      
	</div>
    <div>
      <label class="labelCol" for="myJob">Type of Job: </label>
      <textarea name="myJob" id="myJob" rows="2" cols="20"></textarea>
    </div>
    <div class="mySubmit">
      <input type="submit" value="Free Estimate" />
    </div>
  </form>
<?php include('includes/footer.inc.php'); ?>
